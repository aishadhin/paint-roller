import React from 'react';

const Reviews = () => {
    return (
        <div>
            <h2>Reviews</h2>
        </div>
    );
};

export default Reviews;