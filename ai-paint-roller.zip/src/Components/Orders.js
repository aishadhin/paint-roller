import React from 'react';

const Orders = () => {
    return (
        <div>
            <h2>Orders</h2>
        </div>
    );
};

export default Orders;