import React from "react";

const Button = () => {
  return (
    <div className="text-center ">
      <button
        // style={{
        //   backgroundImage:
        //     "linear-gradient(to right, #0E83CC, #6A469B, #C40B6C)",
        // }}
        className="btn btn-outline btn-primary bg-white mt-5"
      >
        Explore Our Products
      </button>
    </div>
  );
};

export default Button;
